#include <stdio.h>
#include "dev/si7020-driver.h"

#include "i2c.h"

#define SI7020_SLAVE_ADDR 0x40
#define SI7020_RH_CMD 0xE5
#define SI7020_TEMP_CMD 0xE3

#ifndef F_CPU
#define F_CPU 16000000UL
#endif

const struct sensors_sensor si7020_sensor;

void init_uart(uint16_t baudrate){

    uint16_t UBRR_val = (F_CPU/16)/(baudrate-1);

    UBRR0H = UBRR_val >> 8;
    UBRR0L = UBRR_val;

    UCSR0B |= (1<<TXEN0) | (1<<RXEN0) | (1<<RXCIE0); // UART TX (Transmit - senden) einschalten
    UCSR0C |= (1<<USBS0) | (3<<UCSZ00); //Modus Asynchron 8N1 (8 Datenbits, No Parity, 1 Stopbit)
}

int read_humidity() {
    char ms, ls;
    int ack;
    int ret  = 0;

    printf("initializing i2c\n");

    PORTE &= ~(1 << PE7);
    DDRE |= (1 << PE7);

    init_uart(57600);

    i2c_init();
    //-------init sensor
    ack = i2c_start(SI7020_SLAVE_ADDR);
    if (ack) {
        printf ("eerrrorroror\n");
        i2c_stop();
        ack = i2c_start(SI7020_SLAVE_ADDR);
        if (ack) {
            PORTE &= ~(1 << PE7);
            return -1;
        }

    }
    i2c_write(SI7020_RH_CMD);
    printf("after starting and stoping\n");
    i2c_start(SI7020_SLAVE_ADDR + 1);
    ret = ((uint8_t)i2c_read_ack())<<8;
    ret |= i2c_read_ack();
    i2c_stop();




    //i2c_start(SI7020_SLAVE_ADDR);
  //  i2c_write(SI7020_SLAVE_ADDR);
   // i2c_write(SI7020_RH_CMD);
    //i2c_start(SI7020_SLAVE_ADDR);
    //i2c_write(SI7020_SLAVE_ADDR + 1);
    //ms = i2c_read_ack();
    //ls =i2c_read_nack();
    //i2c_stop();
/*
    i2c_start();
    ack = i2c_write(SI7020_SLAVE_ADDR);
    ack = i2c_write(SI7020_RH_CMD);
    i2c_start();
    i2c_write(SI7020_SLAVE_ADDR + 1);
    ms = i2c_read(1);
    ls = i2c_read(0);
    i2c_stop();*/
    //printf("*****Sensor data: %c %c\n", ms, ls);
    //ret = ms;
    //ret = (ret << 8) + ls;
    return ret;
}

static int value(int type)
{
    return read_humidity();
}

static int configure(int type, int c) {
    return type == SENSORS_ACTIVE;
}

static int status(int type) {
     return 1;
}
SENSORS_SENSOR(si7020_sensor, TEMPERATURE_SENSOR, value, configure, status);
